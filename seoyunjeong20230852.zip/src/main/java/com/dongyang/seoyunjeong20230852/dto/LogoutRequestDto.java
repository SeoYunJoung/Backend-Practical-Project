package com.dongyang.seoyunjeong20230852.dto;

import lombok.Getter;

@Getter
public class LogoutRequestDto {
    private String refreshToken;
}