package com.dongyang.seoyunjeong20230852;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Seoyunjeong20230852Application {

	public static void main(String[] args) {
		SpringApplication.run(Seoyunjeong20230852Application.class, args);
	}

}
