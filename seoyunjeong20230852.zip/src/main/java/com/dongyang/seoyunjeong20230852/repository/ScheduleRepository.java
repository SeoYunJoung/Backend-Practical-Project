package com.dongyang.seoyunjeong20230852.repository;

import com.dongyang.seoyunjeong20230852.entity.Schedule;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ScheduleRepository extends JpaRepository<Schedule, Long> {
}