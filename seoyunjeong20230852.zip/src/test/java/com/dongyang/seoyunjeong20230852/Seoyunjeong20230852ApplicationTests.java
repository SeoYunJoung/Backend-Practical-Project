package com.dongyang.seoyunjeong20230852;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Seoyunjeong20230852ApplicationTests {

	@Test
	void contextLoads() {
	}

}
